#pragma once

// Msdlurlgen.h: Global defines for MSDLURLGEN

// Version information (move this to version.h)
#define VERSION_MAJOR 2;
#define VERSION_MINOR 0;
#define VERSION_REVISION 6;